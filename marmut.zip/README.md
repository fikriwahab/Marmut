TK Basdat 3 Front End:
- Fikri Massaid Wahab
- Catur Wira Mukti Nugroho
- Catherine Hana Natalie